# Brick Hill Clone (BLDN Hill)
Straight up terrible. But it's old code that will otherwise rot away, so enjoy, skids.
